package com.example.search;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.SearchView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class SearchAcitivity extends AppCompatActivity {

    private SearchView searchView;
    private RecyclerView recyclerView;
    private ItemAdapter itemAdapter;
    private List<com.example.search.Item> itemList; // Full list of items

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        searchView = findViewById(R.id.search_view);
        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Sample data
        itemList = new ArrayList<>();
        itemList.add(new com.example.search.Item("Apple"));
        itemList.add(new com.example.search.Item("Banana"));
        itemList.add(new com.example.search.Item("Orange"));
        itemList.add(new com.example.search.Item("Grapes"));
        itemList.add(new com.example.search.Item("Mango"));

        // Initialize adapter and set it to RecyclerView
        itemAdapter = new ItemAdapter(itemList);
        recyclerView.setAdapter(itemAdapter);

        // Implement search functionality
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filter(newText);
                return true;
            }
        });
    }

    // Filter items based on search query
    private void filter(String query) {
        List<com.example.search.Item> filteredList = new ArrayList<>();
        if (TextUtils.isEmpty(query)) {
            filteredList.addAll(itemList);
        } else {
            for (com.example.search.Item item : itemList) {
                if (item.getName().toLowerCase().contains(query.toLowerCase())) {
                    filteredList.add(item);
                }
            }
        }
        itemAdapter.updateList(filteredList);
    }
}
