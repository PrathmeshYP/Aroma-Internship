package com.example.search;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.search.R;
import com.example.search.SearchAdapter;

import java.util.ArrayList;
import java.util.List;

class ActivityMain extends AppCompatActivity {

    private EditText searchEditText;
    private RecyclerView searchResultsRecyclerView;
    private SearchAdapter searchAdapter;
    private List<String> itemList;  // List to hold your items (e.g., products, contacts)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);  // Make sure your layout file name is correct

        searchEditText = findViewById(R.id.search_edit_text);
        searchResultsRecyclerView = findViewById(R.id.search_results_recycler_view);

        // Sample item list for demonstration
        itemList = new ArrayList<>();
        itemList.add("Apple");
        itemList.add("Banana");
        itemList.add("Orange");
        itemList.add("Grapes");
        itemList.add("Strawberry");

        searchAdapter = new SearchAdapter(new ArrayList<>());
        searchResultsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        searchResultsRecyclerView.setAdapter(searchAdapter);

        // Add TextWatcher to filter results as the user types
        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                // No action needed here
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                filterResults(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {
                // No action needed here
            }
        });
    }

    private void filterResults(String query) {
        List<String> filteredList = new ArrayList<>();
        for (String item : itemList) {
            if (item.toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(item);
            }
        }

        searchAdapter.updateList(filteredList);

        // Hide keyboard if no input
        if (query.isEmpty()) {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) {
                imm.hideSoftInputFromWindow(searchEditText.getWindowToken(), 0);
            }
        }
    }
}
