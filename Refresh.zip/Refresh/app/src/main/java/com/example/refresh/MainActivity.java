package com.example.refresh;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import android.os.Handler;

import com.example.refresh.MyAdapter;
import com.example.refresh.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private SwipeRefreshLayout swipeRefreshLayout;
    private RecyclerView recyclerView;
    private MyAdapter adapter;
    private List<String> dataList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize SwipeRefreshLayout and RecyclerView
        swipeRefreshLayout = findViewById(R.id.swipe_refresh_layout);
        recyclerView = findViewById(R.id.recycler_view);

        // Set up RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        dataList = new ArrayList<>();
        adapter = new MyAdapter(dataList);
        recyclerView.setAdapter(adapter);

        // Load initial data
        loadData();

        // Pull-to-refresh action
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                // Simulate a network request or data loading
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        // Clear the old data and load new data
                        dataList.clear();
                        loadData();
                        swipeRefreshLayout.setRefreshing(false); // Stop the loading animation
                    }
                }, 2000); // 2 seconds delay for demo purposes
            }
        });
    }

    // Function to load or refresh data
    private void loadData() {
        // Adding some sample data for demonstration
        for (int i = 1; i <= 20; i++) {
            dataList.add("Item " + i);
        }
        adapter.notifyDataSetChanged(); // Notify the adapter that data has changed
    }
}
