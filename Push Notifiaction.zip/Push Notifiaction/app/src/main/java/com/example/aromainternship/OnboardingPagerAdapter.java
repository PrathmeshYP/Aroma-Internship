package com.example.aromainternship;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.aromainternship.OnboardingFragment1;
import com.example.aromainternship.OnboardingFragment2;
import com.example.aromainternship.OnboardingFragment3;

public class OnboardingPagerAdapter extends FragmentStateAdapter {

    public OnboardingPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0:
                return new OnboardingFragment1();
            case 1:
                return new OnboardingFragment2();
            default:
                return new OnboardingFragment3();
        }
    }

    @Override
    public int getItemCount() {
        return 3;
    }
}
