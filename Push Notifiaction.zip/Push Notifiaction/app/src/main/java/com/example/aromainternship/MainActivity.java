package com.example.aromainternship;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText Username, Password;
    private Button SignIn;
    private TextView ForgotPassword, SignUp;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Username = findViewById(R.id.Username);
        Password = findViewById(R.id.Password);
        SignIn = findViewById(R.id.SignIn);
        ForgotPassword = findViewById(R.id.ForgotPassword);
        SignUp = findViewById(R.id.SignUp);

        SignIn.setOnClickListener(v -> {
            String username = Username.getText().toString().trim();
            String password = Password.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please fill out both fields.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Show loading spinner
            progressBar.setVisibility(View.VISIBLE);

            // Simulate login process (replace with actual authentication logic)
            new android.os.Handler().postDelayed(() -> {
                progressBar.setVisibility(View.GONE);

                if (username.equals("admin") && password.equals("password")) {
                    Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                    // Redirect to another activity or home screen
                } else {
                    Toast.makeText(MainActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                }
            }, 2000); // 2 seconds delay for demonstration
        });

        // Set onClickListeners for ForgotPassword and SignUp if needed
        ForgotPassword.setOnClickListener(v -> {
            // Handle forgot password action
            Toast.makeText(MainActivity.this, "Forgot Password Clicked", Toast.LENGTH_SHORT).show();
        });

        SignUp.setOnClickListener(v -> {
            // Handle sign up action
            Toast.makeText(MainActivity.this, "Sign Up Clicked", Toast.LENGTH_SHORT).show();
        });
    }
}
