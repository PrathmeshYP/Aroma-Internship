package com.example.floatingaction;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.example.floatingaction.R;

public class NewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new);

    }
}
